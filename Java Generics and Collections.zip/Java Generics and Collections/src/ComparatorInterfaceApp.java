import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

public class ComparatorInterfaceApp {

    public static void main(String[] args)
    {
        List<Integer> v = new ArrayList<>();
        v.add(887);
        v.add(88);
        v.add(8);
        v.add(77);

        Comparator<Integer> com = new ComImpl();

        Collections.reverse(v,com );

        for (Integer i :v)
        {
            System.out.println(i);
        }

    }
}
