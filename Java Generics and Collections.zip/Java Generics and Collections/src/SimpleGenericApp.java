import java.util.*;


//feach colleciton se use
//  iterator
//  : loop


// Generic can accept many many types
// Generic can't accept indexing, need use List Interface
public class SimpleGenericApp {
    public static void main(String[] args)
    {
        // we can enforce Object type at <>
        //Collection<Integer> values = new ArrayList();
        List<Integer> values = new ArrayList<>();
        values.add(100);
        values.add(3);
        values.add(33);
        values.add(9);
        values.add(99);
        values.add(77);

        values.remove(3);

        //List Interface good at sorting value
        Collections.sort(values);




        for(Integer i : values)
        {
            System.out.println(i);
        }



        // Steam API use Lambda Expression
        //values.forEach(System.out::println);

        //values.add("three");
        //values.add(3.3);

        //Iterator
        /*Iterator i = values.iterator();
        while (i.hasNext())
        {
            System.out.println(i.next());
            System.out.println(i.next());
            System.out.println(i.next());
        }*/


    }

}
