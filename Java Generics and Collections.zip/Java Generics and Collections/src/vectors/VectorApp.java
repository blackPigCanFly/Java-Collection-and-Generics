package vectors;

import java.util.ArrayList;
import java.util.Vector;

// Vector --> auto increase, take more spaces, thread-safe.  NOT COMMON
// ArrayList --> size is static size is not dynamic, dynamic adding fast, not thread safe
// Linklist --> good at when adding
public class VectorApp {
    public static void main(String[] args)
    {
        ArrayList<Double> a = new ArrayList<>();

        System.out.println(a.size());

        /*Vector<Integer> v = new Vector();
        v.add(887);
        v.add(88);
        v.add(8);
        v.add(77);*/


        /*System.out.println("v.capacity() ->" + v.capacity() + "\n");
        for(Integer i : v)
        {
            System.out.println(i);
        }*/



    }
}
